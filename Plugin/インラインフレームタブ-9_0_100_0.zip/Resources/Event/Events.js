var TabManager;
(function (TabManager) {
    /**
     * An event system
     */
    var Events = /** @class */ (function () {
        function Events() {
            this._handlers = {};
        }
        Events.prototype.addHandler = function (eventName, handler) {
            this._ensureEvent(eventName);
            this._handlers[eventName].push(handler);
            return handler;
        };
        Events.prototype.removeHandler = function (eventName, handler) {
            var handlers = this._handlers[eventName];
            if (handlers) {
                var index = handlers.indexOf(handler);
                if (index !== -1) {
                    handlers.splice(index, 1);
                }
            }
        };
        Events.prototype.raiseEvent = function (eventName) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            if (this._handlers[eventName]) {
                this._handlers[eventName].forEach(function (callback) { return callback.apply(void 0, args); });
            }
        };
        Events.prototype.release = function () {
            this._handlers = {};
        };
        Events.prototype._ensureEvent = function (eventName) {
            if (!this._handlers[eventName]) {
                this._handlers[eventName] = [];
            }
        };
        return Events;
    }());
    TabManager.Events = Events;
})(TabManager || (TabManager = {}));
