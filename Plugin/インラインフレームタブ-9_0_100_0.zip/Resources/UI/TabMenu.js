var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    var TabMenuUI = /** @class */ (function (_super) {
        __extends(TabMenuUI, _super);
        function TabMenuUI() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(TabMenuUI.prototype, "activeTab", {
            set: function (value) {
                this.menuListWrap.find(".".concat("FTM-nav-menu-wrap-list-item" /* TabHeadClassNames.NavMenuListItem */)).removeClass("selected" /* TabHeadClassNames.Active */);
                if (value) {
                    this.menuListWrap
                        .find(".".concat("FTM-nav-menu-wrap-list-item" /* TabHeadClassNames.NavMenuListItem */, "[data-uid=").concat(value.uid, "]"))
                        .addClass("selected" /* TabHeadClassNames.Active */);
                }
            },
            enumerable: false,
            configurable: true
        });
        // override
        TabMenuUI.prototype.createContainer = function () {
            this.container = $("<div class='".concat("FTM-nav-menu" /* TabHeadClassNames.NavMenu */, "'></div>"));
            this.bindEvent = this.closeMenuListOnMouseDown.bind(this);
        };
        TabMenuUI.prototype.closeMenuListOnMouseDown = function (ev) {
            var $t = $(ev.target);
            if ($t.hasClass("FTM-nav-menu" /* TabHeadClassNames.NavMenu */)
                || $t.hasClass("FTM-nav-wrap-list-item-close" /* TabHeadClassNames.NavListItemClose */)
                || $t.hasClass("FTM-nav-menu-wrap" /* TabHeadClassNames.NavMenuWrap */)
                || $t.hasClass("FTM-nav-menu-wrap-list" /* TabHeadClassNames.NavMenuList */)
                || $t.hasClass("FTM-nav-menu-wrap-list-item" /* TabHeadClassNames.NavMenuListItem */)) {
                return;
            }
            this.menuListWrap.hide();
        };
        Object.defineProperty(TabMenuUI.prototype, "styleTemplateClassName", {
            get: function () {
                if (!this.target.tabStyle) {
                    return "";
                }
                return "TabManagerTabCellType-".concat(this.target.tabStyle.Key, "-TabItem");
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TabMenuUI.prototype, "menuItemClassName", {
            get: function () {
                return "".concat("FTM-nav-menu-wrap-list-item" /* TabHeadClassNames.NavMenuListItem */, " ").concat("FTM-f-ellipsis" /* FragmentClassNames.Ellipsis */, " ").concat(this.styleTemplateClassName);
            },
            enumerable: false,
            configurable: true
        });
        // override
        TabMenuUI.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            // tabs变化的时候 menu也要重刷一次
            this.target.on("TabsChange" /* TabManagerEvents.TabsChanged */, function () {
                _this.createMenus();
            });
            this.container.on('click', function (ev) {
                if (_this.target.tabList && _this.target.tabList.length > 0) {
                    _this.menuListWrap.show();
                }
                // 如果tab全部关闭 则不需要显示空的menuList
            });
            $("body").off("mousedown", this.bindEvent).on("mousedown", this.bindEvent);
        };
        // override 
        TabMenuUI.prototype.createChildren = function () {
            this.menuListWrap = $("\n<div class=\"".concat("FTM-nav-menu-wrap" /* TabHeadClassNames.NavMenuWrap */, "\">\n    <ul class=\"").concat("FTM-nav-menu-wrap-list" /* TabHeadClassNames.NavMenuList */, "\"></ul>\n</div>"));
            this.createMenus();
            this.container.append(this.menuListWrap);
        };
        TabMenuUI.prototype.createMenus = function () {
            var _a;
            var _this = this;
            var newMenus = this.target.tabList.map(function (t) {
                var tab = $("<li data-uid=\"".concat(t.uid, "\" class=\"").concat(_this.menuItemClassName, "\" style=\"border-radius:0;box-shadow:none;border:none;\"></li>"))
                    .on("click", function (ev) {
                    _this.target.active(t);
                    _this.menuListWrap.hide();
                    ev.stopPropagation();
                });
                tab.text(t.displayedTitle).attr("title", t.displayedTitle);
                if (t.canBeClosed) {
                    var closeIcon = $("<i class=\"".concat("FTM-nav-wrap-list-item-close" /* TabHeadClassNames.NavListItemClose */, "\"></i>")).on("click", function (ev) {
                        _this.target.closeTab(t);
                        _this.menuListWrap.hide();
                    });
                    tab.append(closeIcon);
                }
                if (t === _this.target.activeTab) {
                    tab.addClass("selected" /* TabHeadClassNames.Active */);
                }
                return tab;
            });
            this.menuListWrap.find('ul').empty();
            (_a = this.menuListWrap.find('ul')).append.apply(_a, newMenus);
        };
        return TabMenuUI;
    }(TabManager.ControlUIBase));
    TabManager.TabMenuUI = TabMenuUI;
})(TabManager || (TabManager = {}));
